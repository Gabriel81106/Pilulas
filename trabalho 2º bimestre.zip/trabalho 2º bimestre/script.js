let botaoTriangulo = document.querySelector("#botaoTriangulo");
let botaoIMC = document.querySelector("#botaoIMC");
let botaoImposto = document.querySelector("#botaoImposto");
let botaoSalario = document.querySelector("#botaoSalario");
let botaoBancario = document.querySelector("#botaoBancario");
let botaoLanchonete = document.querySelector("#botaoLanchonete");
let botaoSistemaVenda = document.querySelector("#botaoSistemaVenda");
let botaoSistemaPagamento = document.querySelector("#botaoSistemaPagamento");


function TrocaAbas(index) {
    let tabs = document.querySelectorAll('.aba');
    tabs.forEach((aba, i) => {
        if (i === index) {
            aba.style.display = 'block';
        }else {
            aba.style.display = 'none';
        }
    })
}

botaoTriangulo.onclick = function() {
    TrocaAbas(0);
}
botaoIMC.onclick = function() {
    TrocaAbas(1);
}
botaoImposto.onclick = function() {
    TrocaAbas(2);
}
botaoSalario.onclick = function() {
    TrocaAbas(3);
}
botaoBancario.onclick = function() {
    TrocaAbas(4);
}
botaoLanchonete.onclick = function() {
    TrocaAbas(5);
}
botaoSistemaVenda.onclick = function() {
    TrocaAbas(6);
}
botaoSistemaPagamento.onclick = function() {
    TrocaAbas(7);
}

//////////////// TRIANGULOS ////////////////////
let x = document.querySelector("#x");
let y = document.querySelector("#y");
let z = document.querySelector("#z");
let botaoCalcularTriangulo = document.querySelector("#botaoCalcularTriangulo");
let resultadoTriangulo = document.querySelector("#resultadoTriangulo");

function TrocaTriangulo(tipo) {
    let troca = document.querySelectorAll('#imgTriangulo');
    troca.forEach((imgTriangulo, i) => {
        if (i === tipo) {
            imgTriangulo.style.display = 'block';
        }else {
            imgTriangulo.style.display = 'none';
        }
    })
}

function calcularTriangulo() {
      const x = parseFloat(document.getElementById('x').value);
      const y = parseFloat(document.getElementById('y').value);
      const z = parseFloat(document.getElementById('z').value);

      if (x < y + z && y < x + z && z < x + y) {
        if (x === y && y === z) {
          resultadoTriangulo.textContent = 'Seu triângulo é equilátero.';
            TrocaTriangulo(0);
        } else if (x === y || x === z || y === z) {
          resultadoTriangulo.textContent = 'Seu triângulo é isósceles.';
            TrocaTriangulo(1);
        } else {
          resultadoTriangulo.textContent = 'Seu triângulo é escaleno.';
            TrocaTriangulo(2);
        }
      } else {
        resultadoTriangulo.textContent = 'Os valores não formam um triângulo.';
      }
    }

botaoCalcularTriangulo.onclick = function() {
    calcularTriangulo();
}

//////////////// IMC ////////////////////
let peso = document.querySelector("#peso");
let altura = document.querySelector("#altura");
let botaoCalcularIMC = document.querySelector("#botaoCalcularIMC");
let resultadoIMC = document.querySelector("#resultadoIMC");

function calcularIMC(){
    let num1 = Number(peso.value);
    let num2 = Number(altura.value);
    let imcCalculado = num1 / (num2 * num2);

    if(imcCalculado < 18.5) {
        resultadoIMC.innerHTML = `Seu IMC é de ${imcCalculado.toFixed(2)} Você está abaixo do peso.<br>Cuidado!`;
    }else if(imcCalculado >= 18.5 && imcCalculado < 24.9) {
        resultadoIMC.innerHTML = `Seu IMC é de ${imcCalculado.toFixed(2)} Você está com o peso normal.<br>Parabéns!`;
    }else if(imcCalculado >=25 && imcCalculado <29.9){
        resultadoIMC.innerHTML = `Seu IMC é de ${imcCalculado.toFixed(2)} Você está com sobrepeso.<br>Fique atento!`;
    }else if(imcCalculado >= 30 && imcCalculado < 34.9) {
        resultadoIMC.innerHTML = `Seu IMC é de ${imcCalculado.toFixed(2)} Você está com obesidade grau 1.<br>Cuidado!`;
    }else if(imcCalculado >= 35 && imcCalculado < 39.9) {
        resultadoIMC.innerHTML = `Seu IMC é de ${imcCalculado.toFixed(2)} Você está com obesidade grau 2.<br>Cuidado!`; 
    }else if(imcCalculado >= 40) {
        resultadoIMC.innerHTML = `Seu IMC é de ${imcCalculado.toFixed(2)} Você está com obesidade grau 3.<br>Cuidado!`;
    }
}  

botaoCalcularIMC.onclick = function() {
    calcularIMC();
}

//////////////// IMPOSTO ////////////////////
let valorCarro = document.querySelector("#valorCarro");
let epocaCarro = document.querySelector("#anoCarro");
let botaoCalcularImposto = document.querySelector("#botaoCalcularImposto");
let resultadoImposto = document.querySelector("#resultadoImposto");

function calcularImposto() {
    let valor = Number(valorCarro.value);
    let anoCarro = (epocaCarro.value);
    

    if (anoCarro === "antes90") {
        let valorCarroFinal = valor + (valor * 0.01);
        resultadoImposto.innerHTML = `Valor da transferência: ${valorCarroFinal.toFixed(2)}`;
    }else{
        let valorCarroFinal = valor + (valor * 0.015);
        resultadoImposto.innerHTML = `Valor da transferência: ${valorCarroFinal.toFixed(2)}`;
    }
}

botaoCalcularImposto.onclick = function() {
    calcularImposto();
}
//////////////// SALARIO ////////////////////
let salario = document.querySelector("#salario");
let cargo = document.querySelector("#cargo");
let botaoCalcularSalario = document.querySelector("#botaoCalcularSalario");
let salarioAntigo = document.querySelector("#salarioAntigo");
let salarioNovo = document.querySelector("#salarioNovo");
let salarioDiferenca = document.querySelector("#salarioDiferenca");

function calcularSalario() {
    let codigoCargo = cargo.value;
    let salarioAtual = Number(salario.value);

    if (codigoCargo == 101){
        salarioNovo.textContent = "Salário Novo: " + (salarioAtual + (salarioAtual * 0.1));
        salarioAntigo.textContent = "Salário Antigo: " + (salario.value)
        salarioDiferenca.textContent = "Diferença do Salário Antigo para o Novo: " + (salarioAtual * 0.1).toFixed(2);

    }else if (codigoCargo == 102){
        salarioNovo.textContent = "Salário Novo: " + (salarioAtual + (salarioAtual * 0.2));
        salarioAntigo.textContent = "Salário Antigo: " + (salario.value)
        salarioDiferenca.textContent = "Diferença do Salário Antigo para o Novo: " + (salarioAtual * 0.1).toFixed(2);

    }else if (codigoCargo == 103){
        salarioNovo.textContent = "Salário Novo: " + (salarioAtual + (salarioAtual * 0.3));
        salarioAntigo.textContent = "Salário Antigo: " + (salario.value)
        salarioDiferenca.textContent = "Diferença do Salário Antigo para o Novo: " + (salarioAtual * 0.1).toFixed(2);

    }else {
        salarioNovo.textContent = "Salário Novo: " + (salarioAtual + (salarioAtual * 0.4));
        salarioAntigo.textContent = "Salário Antigo: " + (salario.value)
        salarioDiferenca.textContent = "Diferença do Salário Antigo para o Novo: " + (salarioAtual * 0.1).toFixed(2);
    }
}

botaoCalcularSalario.onclick = function() {
    calcularSalario();
}
//////////////// BANCO ////////////////////
let saldoMedio = document.querySelector("#saldoMedio")
let botaoCalcularCredito = document.querySelector("#botaoCalcularCredito")
let resultadoCredito = document.querySelector("#resultadoCredito")

function calcularCredito(){
    let saldo = Number(saldoMedio.value)

    if (saldo <= 200 ) {
        resultadoCredito.innerHTML = `Saldo Médio: ${saldo.toFixed(2)}<br>Valor do Crédito: 0`
    }else if (saldo >= 201 && saldo <= 400){
        let credito = saldo * 0.2;
        resultadoCredito.innerHTML = `Saldo Médio: ${saldo.toFixed(2)}<br>Valor do Crédito (20%): ${credito.toFixed(2)}`
    }else if (saldo >= 401 && saldo <=600) {
        let credito = saldo * 0.3;
        resultadoCredito.innerHTML = `Saldo Médio: ${saldo.toFixed(2)}<br>Valor do Crédito (30%): ${credito.toFixed(2)}`
    }else if (saldo > 600) {
        let credito = saldo * 0.4;
        resultadoCredito.innerHTML = `Saldo Médio: ${saldo.toFixed(2)}<br>Valor do Crédito (40%): ${credito.toFixed(2)}`
    }
}

botaoCalcularCredito.onclick = function() {
    calcularCredito();
}

/////////////// LANCHONETE ////////////////////
let produtos = document.querySelector("#produtos");
let quantidade = document.querySelector("#quantidade");
let botaoCalcularLanchonete = document.querySelector("#botaoCalcularLanchonete");
let resultadoLanchonete = document.querySelector("#resultadoLanchonete");

function calcularLanchonete() {
    let quantidadeProdutos = Number(quantidade.value);
    let produtoSelecionado = produtos.value;

    if (produtoSelecionado === "hotdog") {
        let valorTotal = quantidadeProdutos * 11;
        resultadoLanchonete.innerHTML = `O valor total do pedido é: R$ ${valorTotal.toFixed(2)}`;
    }else if (produtoSelecionado === "bauru") {
        let valorTotal = quantidadeProdutos * 8.5;
        resultadoLanchonete.innerHTML = `O valor total do pedido é: R$ ${valorTotal.toFixed(2)}`;
    }else if (produtoSelecionado === "misto") {
        let valorTotal = quantidadeProdutos * 8;
        resultadoLanchonete.innerHTML = `O valor total do pedido é: R$ ${valorTotal.toFixed(2)}`;
    }else if (produtoSelecionado === "hamburger") {
        let valorTotal = quantidadeProdutos * 9;
        resultadoLanchonete.innerHTML = `O valor total do pedido é: R$ ${valorTotal.toFixed(2)}`;
    }else if (produtoSelecionado === "cheeseburger") {
        let valorTotal = quantidadeProdutos * 10;
        resultadoLanchonete.innerHTML = `O valor total do pedido é: R$ ${valorTotal.toFixed(2)}`;
    }else if (produtoSelecionado === "refri") {
        let valorTotal = quantidadeProdutos * 4.5;
        resultadoLanchonete.innerHTML = `O valor total do pedido é: R$ ${valorTotal.toFixed(2)}`;
    }else {
        resultadoLanchonete.innerHTML = "Produto não encontrado.";
    }
}

botaoCalcularLanchonete.onclick = function() {
    calcularLanchonete();
}

//////////////// SISTEMA DE VENDA ////////////////////
let valorProduto = document.querySelector("#valorProduto");
let condicaoPagamento = document.querySelector("#condicaoPagamento");
let botaoCalcularVenda = document.querySelector("#botaoCalcularVenda");
let resultadoVenda = document.querySelector("#resultadoVenda");

function calcularVenda() {
    let valor = Number(valorProduto.value);
    let condicao = condicaoPagamento.value;
    
    if (condicao == "avistaDinheiro") {
        let valorFinal = valor + (valor * 0.1);
        resultadoVenda.innerHTML = `O valor total do pedido é: R$ ${valorFinal.toFixed(2)}`;
    }else if (condicao == "avistaCredito") {
        let valorTotal = valor + (valor * 0.15);
        resultadoVenda.innerHTML = `O valor total do pedido é: R$ ${valorTotal.toFixed(2)}`;
    }else if (condicao == "duasVezesZeroJuros") {
        let valorTotal = valor;
        resultadoVenda.innerHTML = `O valor total do pedido é: R$ ${valorTotal.toFixed(2)}`;
    }else{
        let valorTotal = valor - (valor * 0.1);
        resultadoVenda.innerHTML = `O valor total do pedido é: R$ ${valorTotal.toFixed(2)}`;
    }
}

botaoCalcularVenda.onclick = function() {
    calcularVenda();
}

//////////////// SISTEMA DE PAGAMENTO ////////////////////
let nivelProfessor = document.querySelector("#nivelProfessor");
let HoraAula = document.querySelector("#HoraAula");
let botaoCalcularPagamento = document.querySelector("#botaoCalcularPagamento");
let resultadoPagamento = document.querySelector("#resultadoPagamento");

function calcularPagamento() {
    let HoraTrabalhada = Number(HoraAula.value)
    let nivel = nivelProfessor.value;

    if (nivel === "nivel1") {
        let salarioProf = 12 * HoraTrabalhada * 4.5;
        resultadoPagamento.innerHTML = "Sálario: R$ " + salarioProf.toFixed(2);
    }else if (nivel === "nivel2") {
        let salarioProf = 17 * HoraTrabalhada * 4.5;
        resultadoPagamento.innerHTML = "Sálario: R$ " + salarioProf.toFixed(2);
    }else {
        let salarioProf = 25 * HoraTrabalhada * 4.5;
        resultadoPagamento.innerHTML = "Sálario: R$ " + salarioProf.toFixed(2);
    }
}

botaoCalcularPagamento.onclick = function() {
    calcularPagamento();
}