let input1 = document.querySelector('#reajuste')
let botao = document.querySelector('#botao')
let resultado = document.querySelector('#resultado')